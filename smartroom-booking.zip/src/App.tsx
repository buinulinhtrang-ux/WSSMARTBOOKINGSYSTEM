import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Users, MapPin, Plus, Check, AlertCircle, ChevronLeft, ChevronRight, Search, LogIn, LogOut, User as UserIcon, Lock, Briefcase, Car, Building2, Plane, Layers, Bell, Eye, Languages } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Room, Booking, User, BusinessTrip, VehicleBooking, Notification } from './types';
import { translations, Language } from './translations';

const Workflow = ({ status, createdAt, processedAt, hrComment, type, lang }: { status: string, createdAt?: string, processedAt?: string, hrComment?: string, type?: 'TRIP' | 'VEHICLE', lang: Language }) => {
  const t = translations[lang];
  const approverLabel = type === 'VEHICLE' ? t.hcthFeedback : t.hrFeedback;
  const steps = [
    { label: t.submitted, date: createdAt, completed: true, icon: <Check size={14} /> },
    { label: `${t.processing} (${type === 'VEHICLE' ? (lang === 'vi' ? 'Khối HCTH-DVHS' : 'Admin Dept') : 'HR'})`, date: status === 'PENDING' ? (lang === 'vi' ? 'Đang chờ...' : 'Waiting...') : processedAt, completed: status !== 'PENDING', icon: status === 'PENDING' ? <Clock size={14} /> : <Check size={14} /> },
    { label: status === 'APPROVED' ? t.approvedStatus : status === 'REJECTED' ? t.rejectedStatus : t.completed, date: processedAt, completed: status !== 'PENDING', icon: status === 'APPROVED' ? <Check size={14} /> : status === 'REJECTED' ? <Plus size={14} className="rotate-45" /> : <Clock size={14} /> }
  ];

  return (
    <div className="space-y-6">
      <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-4">{t.approvalProcess}</h4>
      <div className="relative pl-8 space-y-8 before:absolute before:left-[15px] before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100">
        {steps.map((step, i) => (
          <div key={i} className="relative">
            <div className={`absolute -left-8 w-8 h-8 rounded-full flex items-center justify-center border-2 z-10 ${
              step.completed ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-gray-200 text-gray-300'
            }`}>
              {step.icon}
            </div>
            <div>
              <p className={`text-sm font-bold ${step.completed ? 'text-gray-900' : 'text-gray-400'}`}>{step.label}</p>
              {step.date && <p className="text-[10px] text-gray-400 mt-1">{new Date(step.date).toLocaleString(lang === 'vi' ? 'vi-VN' : 'en-US')}</p>}
            </div>
          </div>
        ))}
      </div>
      {hrComment && (
        <div className="mt-4 p-4 bg-amber-50 rounded-2xl border border-amber-100">
          <p className="text-[10px] text-amber-600 font-bold uppercase mb-1">{approverLabel}</p>
          <p className="text-sm text-amber-800 italic">"{hrComment}"</p>
        </div>
      )}
    </div>
  );
};

export default function App() {
  const [lang, setLang] = useState<Language>('vi');
  const t = translations[lang];
  const [user, setUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState<'ROOMS' | 'TRIPS' | 'VEHICLES'>('ROOMS');
  const [rooms, setRooms] = useState<Room[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [trips, setTrips] = useState<BusinessTrip[]>([]);
  const [vehicleBookings, setVehicleBookings] = useState<VehicleBooking[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [isTripModalOpen, setIsTripModalOpen] = useState(false);
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [editingTripId, setEditingTripId] = useState<number | null>(null);
  const [editingVehicleId, setEditingVehicleId] = useState<number | null>(null);
  const [selectedTrip, setSelectedTrip] = useState<BusinessTrip | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleBooking | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [suggestions, setSuggestions] = useState<Room[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Login state
  const [loginData, setLoginData] = useState({ employeeId: '', password: '' });
  const [loginError, setLoginError] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    organizer: '',
    participants: 2,
    location: 'Tất cả',
    startTime: '09:00',
    endTime: '10:00',
    roomId: 0,
    invitedUserIds: [] as string[],
    externalParticipants: [] as string[]
  });

  const [tripFormData, setTripFormData] = useState({
    destination: '',
    purpose: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    city: '',
    hotelCheckIn: new Date().toISOString().split('T')[0],
    hotelCheckOut: new Date().toISOString().split('T')[0],
    notes: '',
    followers: [] as string[],
    participants: [
      { name: '', position: '', department: '', phone: '' }
    ],
    rooms: [
      { room_number: 1, room_type: 'Single' as const, guest_ids: [] as string[] }
    ]
  });

  const [vehicleFormData, setVehicleFormData] = useState({
    pickupLocation: '',
    destination: '',
    date: new Date().toISOString().split('T')[0],
    pickupTime: '08:00',
    passengers: 1,
    invitedUserIds: [] as string[],
    externalParticipants: [] as string[]
  });

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    loadRooms();
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const res = await fetch('/api/users');
    const data = await res.json();
    setUsers(data);
  };

  useEffect(() => {
    if (user) {
      loadBookings(selectedDate);
      loadTrips();
      loadVehicleBookings();
      loadNotifications();
    }
  }, [selectedDate, user]);

  const loadNotifications = async () => {
    if (!user) return;
    const res = await fetch(`/api/notifications?user_id=${user.id}`);
    const data = await res.json();
    setNotifications(data);
  };

  const markNotificationAsRead = async (id: number) => {
    await fetch(`/api/notifications/${id}/read`, { method: 'POST' });
    loadNotifications();
  };

  const loadTrips = async () => {
    const userIdParam = user?.role === 'HR_MANAGER' ? '' : (user?.id || '');
    const res = await fetch(`/api/trips?user_id=${userIdParam}`);
    const data = await res.json();
    setTrips(data);
  };

  const loadVehicleBookings = async () => {
    const userIdParam = user?.role === 'HR_MANAGER' ? '' : (user?.id || '');
    const res = await fetch(`/api/vehicles?user_id=${userIdParam}&type=DAILY`);
    const data = await res.json();
    setVehicleBookings(data);
  };

  useEffect(() => {
    if (user) {
      setFormData(prev => ({ ...prev, organizer: user.name }));
    }
  }, [user]);

  useEffect(() => {
    if (isBookingModalOpen) {
      const total = 1 + formData.invitedUserIds.length + formData.externalParticipants.length;
      setFormData(prev => ({ ...prev, participants: total }));
    }
  }, [formData.invitedUserIds, formData.externalParticipants, isBookingModalOpen]);

  const loadRooms = async () => {
    const res = await fetch('/api/rooms');
    const data = await res.json();
    setRooms(data);
  };

  const loadBookings = async (date: string) => {
    const res = await fetch(`/api/bookings?date=${date}&user_id=${user?.id || ''}`);
    const data = await res.json();
    setBookings(data);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData)
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data);
        localStorage.setItem('user', JSON.stringify(data));
      } else {
        setLoginError(data.error);
      }
    } catch (err) {
      setLoginError("Có lỗi xảy ra khi đăng nhập.");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const handleSuggest = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participants: formData.participants,
          location: formData.location,
          start_time: `${selectedDate} ${formData.startTime}:00`,
          end_time: `${selectedDate} ${formData.endTime}:00`
        })
      });
      const data = await res.json();
      setSuggestions(data);
      if (data.length === 0) {
        setError(lang === 'vi' ? "Không tìm thấy phòng phù hợp trống lịch." : "No suitable rooms found.");
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi tìm phòng." : "Error finding rooms.");
    } finally {
      setLoading(false);
    }
  };

  const handleBooking = async () => {
    if (!formData.roomId) {
      setError(lang === 'vi' ? "Vui lòng chọn một phòng." : "Please select a room.");
      return;
    }

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          room_id: formData.roomId,
          title: formData.title,
          organizer_id: user?.id,
          organizer_name: user?.name,
          participants_count: formData.participants,
          start_time: `${selectedDate} ${formData.startTime}:00`,
          end_time: `${selectedDate} ${formData.endTime}:00`,
          invited_user_ids: formData.invitedUserIds,
          external_participants: formData.externalParticipants
        })
      });

      if (res.status === 409) {
        const data = await res.json();
        setError(data.error);
        return;
      }

      setSuccess(lang === 'vi' ? "Đặt phòng thành công!" : "Room booked successfully!");
      setIsBookingModalOpen(false);
      loadBookings(selectedDate);
      // Reset form
      setFormData({
        title: '',
        organizer: user?.name || '',
        participants: 2,
        location: 'Tất cả',
        startTime: '09:00',
        endTime: '10:00',
        roomId: 0,
        invitedUserIds: [] as string[],
        externalParticipants: [] as string[]
      });
      setSuggestions([]);
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi đặt phòng." : "Error booking room.");
    }
  };

  const handleRSVP = async (bookingId: number, status: 'ACCEPTED' | 'DECLINED') => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/rsvp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: user?.id, status })
      });
      if (res.ok) {
        setSuccess(status === 'ACCEPTED' ? (lang === 'vi' ? "Đã xác nhận tham gia!" : "Joined confirmed!") : (lang === 'vi' ? "Đã từ chối tham gia." : "Joined declined."));
        loadBookings(selectedDate);
        setTimeout(() => setSuccess(null), 3000);
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi phản hồi." : "Error responding.");
    }
  };

  const handleCancelBooking = async (id: number) => {
    if (!confirm(lang === 'vi' ? "Bạn có chắc chắn muốn hủy cuộc họp này?" : "Are you sure you want to cancel this meeting?")) return;
    try {
      const res = await fetch(`/api/bookings/${id}?user_id=${user?.id}`, { method: 'DELETE' });
      if (res.ok) {
        setSuccess(lang === 'vi' ? "Đã hủy cuộc họp thành công." : "Meeting cancelled successfully.");
        loadBookings(selectedDate);
        setSelectedBooking(null);
        setTimeout(() => setSuccess(null), 3000);
      } else {
        const data = await res.json();
        setError(data.error);
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi hủy cuộc họp." : "Error cancelling meeting.");
    }
  };

  const handleCancelTrip = async (id: number) => {
    if (!confirm(lang === 'vi' ? "Bạn có chắc chắn muốn hủy yêu cầu công tác này?" : "Are you sure you want to cancel this trip request?")) return;
    try {
      const res = await fetch(`/api/trips/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setSuccess(lang === 'vi' ? "Đã hủy yêu cầu công tác thành công." : "Trip request cancelled successfully.");
        loadTrips();
        setSelectedTrip(null);
        setTimeout(() => setSuccess(null), 3000);
      } else {
        const data = await res.json();
        setError(data.error);
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi hủy yêu cầu." : "Error cancelling request.");
    }
  };

  const handleCancelVehicle = async (id: number) => {
    if (!confirm(lang === 'vi' ? "Bạn có chắc chắn muốn hủy yêu cầu đặt xe này?" : "Are you sure you want to cancel this vehicle request?")) return;
    try {
      const res = await fetch(`/api/vehicles/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setSuccess(lang === 'vi' ? "Đã hủy yêu cầu đặt xe thành công." : "Vehicle request cancelled successfully.");
        loadVehicleBookings();
        setSelectedVehicle(null);
        setTimeout(() => setSuccess(null), 3000);
      } else {
        const data = await res.json();
        setError(data.error);
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi hủy yêu cầu." : "Error cancelling request.");
    }
  };

  const addParticipant = () => {
    setTripFormData({
      ...tripFormData,
      participants: [...tripFormData.participants, { name: '', position: '', department: '', phone: '' }]
    });
  };

  const removeParticipant = (index: number) => {
    const newParticipants = [...tripFormData.participants];
    newParticipants.splice(index, 1);
    setTripFormData({ ...tripFormData, participants: newParticipants });
  };

  const addRoom = () => {
    setTripFormData({
      ...tripFormData,
      rooms: [...tripFormData.rooms, { room_number: tripFormData.rooms.length + 1, room_type: 'Single', guest_ids: [] }]
    });
  };

  const removeRoom = (index: number) => {
    const newRooms = [...tripFormData.rooms];
    newRooms.splice(index, 1);
    setTripFormData({ ...tripFormData, rooms: newRooms });
  };

  const handleTripBooking = async () => {
    try {
      const url = editingTripId ? `/api/trips/${editingTripId}` : '/api/trips';
      const method = editingTripId ? 'PUT' : 'POST';
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          destination: tripFormData.destination,
          purpose: tripFormData.purpose,
          start_date: tripFormData.startDate,
          end_date: tripFormData.endDate,
          city: tripFormData.city,
          hotel_check_in: tripFormData.hotelCheckIn,
          hotel_check_out: tripFormData.hotelCheckOut,
          notes: tripFormData.notes,
          participants: tripFormData.participants,
          rooms: tripFormData.rooms,
          followers: tripFormData.followers
        })
      });

      if (res.ok) {
        setSuccess(editingTripId ? (lang === 'vi' ? "Cập nhật yêu cầu thành công!" : "Request updated successfully!") : (lang === 'vi' ? "Đã gửi yêu cầu công tác!" : "Trip request sent!"));
        setIsTripModalOpen(false);
        setEditingTripId(null);
        loadTrips();
        // Reset form
        setTripFormData({
          destination: '',
          purpose: '',
          startDate: new Date().toISOString().split('T')[0],
          endDate: new Date().toISOString().split('T')[0],
          city: '',
          hotelCheckIn: new Date().toISOString().split('T')[0],
          hotelCheckOut: new Date().toISOString().split('T')[0],
          notes: '',
          followers: [],
          participants: [
            { name: '', position: '', department: '', phone: '' }
          ],
          rooms: [
            { room_number: 1, room_type: 'Single' as const, guest_ids: [] as string[] }
          ]
        });
        setTimeout(() => setSuccess(null), 3000);
      } else {
        const data = await res.json();
        setError(data.error);
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi gửi yêu cầu." : "Error sending request.");
    }
  };

  const handleEditTrip = (trip: BusinessTrip) => {
    setEditingTripId(trip.id);
    setTripFormData({
      destination: trip.destination,
      purpose: trip.purpose,
      startDate: trip.start_date,
      endDate: trip.end_date,
      city: trip.city || '',
      hotelCheckIn: trip.hotel_check_in || '',
      hotelCheckOut: trip.hotel_check_out || '',
      notes: trip.notes || '',
      followers: trip.followers || [],
      participants: trip.participants.length > 0 ? trip.participants : [{ name: '', position: '', department: '', phone: '' }],
      rooms: trip.rooms.length > 0 ? trip.rooms : [{ room_number: 1, room_type: 'Single', guest_ids: [] }]
    });
    setIsTripModalOpen(true);
  };

  const handleVehicleBooking = async () => {
    try {
      const url = editingVehicleId ? `/api/vehicles/${editingVehicleId}` : '/api/vehicles';
      const method = editingVehicleId ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          pickup_location: vehicleFormData.pickupLocation,
          destination: vehicleFormData.destination,
          pickup_time: `${vehicleFormData.date} ${vehicleFormData.pickupTime}:00`,
          passengers: vehicleFormData.passengers,
          invited_user_ids: vehicleFormData.invitedUserIds,
          external_participants: vehicleFormData.externalParticipants
        })
      });

      if (res.ok) {
        setSuccess(editingVehicleId ? (lang === 'vi' ? "Cập nhật yêu cầu thành công!" : "Request updated successfully!") : (lang === 'vi' ? "Đặt xe thành công!" : "Vehicle booked successfully!"));
        setIsVehicleModalOpen(false);
        setEditingVehicleId(null);
        loadVehicleBookings();
        // Reset form
        setVehicleFormData({
          pickupLocation: '',
          destination: '',
          date: new Date().toISOString().split('T')[0],
          pickupTime: '08:00',
          passengers: 1,
          invitedUserIds: [],
          externalParticipants: []
        });
        setTimeout(() => setSuccess(null), 3000);
      } else {
        const data = await res.json();
        setError(data.error);
      }
    } catch (err) {
      setError(lang === 'vi' ? "Có lỗi xảy ra khi đặt xe." : "Error booking vehicle.");
    }
  };

  const handleEditVehicle = (v: VehicleBooking) => {
    setEditingVehicleId(v.id);
    const [date, time] = v.pickup_time.split(' ');
    setVehicleFormData({
      pickupLocation: v.pickup_location,
      destination: v.destination,
      date: date,
      pickupTime: time.substring(0, 5),
      passengers: v.passengers,
      invitedUserIds: v.invited_participants.map(p => p.user_id),
      externalParticipants: v.external_participants
    });
    setIsVehicleModalOpen(true);
  };

  const locations = ["Tất cả", ...Array.from(new Set(rooms.map(r => r.location)))];

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center p-4 font-sans">
        <div className="absolute top-4 right-4 flex gap-2">
          <button 
            onClick={() => setLang(lang === 'vi' ? 'en' : 'vi')}
            className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-2 text-sm font-bold text-gray-600 hover:bg-gray-50 transition-all"
          >
            <Languages size={18} className="text-indigo-600" />
            {lang === 'vi' ? 'English' : 'Tiếng Việt'}
          </button>
        </div>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
        >
          <div className="p-8">
            <div className="flex flex-col items-center mb-8">
              <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg shadow-indigo-200">
                <Calendar size={32} />
              </div>
              <h1 className="text-2xl font-bold tracking-tight text-gray-900">{t.appName}</h1>
              <p className="text-gray-500 text-sm mt-1">{lang === 'vi' ? 'Đăng nhập để bắt đầu' : 'Login to start'}</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{t.employeeId}</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input 
                    type="text" 
                    placeholder={lang === 'vi' ? "Ví dụ: EMP001" : "Example: EMP001"}
                    className="w-full bg-gray-50 border-none rounded-xl pl-12 pr-4 py-4 focus:ring-2 focus:ring-indigo-500 transition-all"
                    value={loginData.employeeId}
                    onChange={e => setLoginData({...loginData, employeeId: e.target.value})}
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{t.password}</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input 
                    type="password" 
                    placeholder={lang === 'vi' ? "Mật khẩu (mã nhân viên)" : "Password (employee ID)"}
                    className="w-full bg-gray-50 border-none rounded-xl pl-12 pr-4 py-4 focus:ring-2 focus:ring-indigo-500 transition-all"
                    value={loginData.password}
                    onChange={e => setLoginData({...loginData, password: e.target.value})}
                    required
                  />
                </div>
              </div>

              {loginError && (
                <div className="bg-red-50 text-red-600 p-3 rounded-xl text-sm flex items-center gap-2">
                  <AlertCircle size={16} />
                  {loginError}
                </div>
              )}

              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-indigo-200 transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (lang === 'vi' ? "Đang xử lý..." : "Processing...") : (
                  <>
                    {t.login}
                    <LogIn size={20} />
                  </>
                )}
              </button>
            </form>
            
            <div className="mt-8 pt-6 border-t border-gray-100 text-center">
              <p className="text-xs text-gray-400">{lang === 'vi' ? 'Gợi ý: Thử với mã nhân viên' : 'Hint: Try with employee ID'} <span className="font-bold text-gray-600">EMP001</span></p>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Calendar size={24} />
          </div>
          <h1 className="text-xl font-bold tracking-tight">{t.appName}</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex bg-gray-100 p-1 rounded-xl mr-2">
            <button 
              onClick={() => setLang('vi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${lang === 'vi' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              VN
            </button>
            <button 
              onClick={() => setLang('en')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${lang === 'en' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              EN
            </button>
          </div>
          <nav className="flex bg-gray-100 p-1 rounded-xl mr-4">
            <button 
              onClick={() => setCurrentTab('ROOMS')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${currentTab === 'ROOMS' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Building2 size={18} /> {t.rooms}
            </button>
            <button 
              onClick={() => setCurrentTab('TRIPS')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${currentTab === 'TRIPS' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Briefcase size={18} /> {t.trips}
            </button>
            <button 
              onClick={() => setCurrentTab('VEHICLES')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${currentTab === 'VEHICLES' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Car size={18} /> {t.vehicles}
            </button>
          </nav>

          <div className="flex items-center bg-gray-100 rounded-full px-4 py-2 gap-2">
            <button 
              onClick={() => {
                const d = new Date(selectedDate);
                d.setDate(d.getDate() - 1);
                setSelectedDate(d.toISOString().split('T')[0]);
              }}
              className="hover:text-indigo-600 transition-colors"
            >
              <ChevronLeft size={20} />
            </button>
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent border-none focus:ring-0 text-sm font-medium cursor-pointer"
            />
            <button 
              onClick={() => {
                const d = new Date(selectedDate);
                d.setDate(d.getDate() + 1);
                setSelectedDate(d.toISOString().split('T')[0]);
              }}
              className="hover:text-indigo-600 transition-colors"
            >
              <ChevronRight size={20} />
            </button>
          </div>
          
          <div className="h-8 w-[1px] bg-gray-200 mx-2"></div>
          
          <div className="relative">
            <button 
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="p-2 hover:bg-gray-100 rounded-full transition-all relative"
            >
              <Bell size={20} className="text-gray-600" />
              {notifications.filter(n => !n.is_read).length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] flex items-center justify-center rounded-full border-2 border-white">
                  {notifications.filter(n => !n.is_read).length}
                </span>
              )}
            </button>

            <AnimatePresence>
              {isNotificationsOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50"
                >
                  <div className="p-4 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-bold text-sm">{t.notifications}</h3>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider font-bold">{lang === 'vi' ? 'Mới nhất' : 'Latest'}</span>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-8 text-center text-gray-400 text-sm">
                        {t.noNotifications}
                      </div>
                    ) : (
                      notifications.map(n => (
                        <div 
                          key={n.id} 
                          onClick={() => markNotificationAsRead(n.id)}
                          className={`p-4 border-b border-gray-50 hover:bg-gray-50 transition-colors cursor-pointer ${!n.is_read ? 'bg-indigo-50/30' : ''}`}
                        >
                          <p className="text-sm text-gray-800 leading-relaxed">{n.message}</p>
                          <p className="text-[10px] text-gray-400 mt-2 flex items-center gap-1">
                            <Clock size={10} />
                            {new Date(n.created_at).toLocaleString(lang === 'vi' ? 'vi-VN' : 'en-US')}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-sm font-bold text-gray-900">{user.name}</div>
              <div className="text-[10px] text-gray-400 uppercase tracking-wider">{user.id}</div>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2.5 bg-gray-100 hover:bg-red-50 hover:text-red-600 rounded-full transition-all group"
              title={t.logout}
            >
              <LogOut size={20} />
            </button>
          </div>

          <button 
            onClick={() => {
              if (currentTab === 'ROOMS') setIsBookingModalOpen(true);
              if (currentTab === 'TRIPS') setIsTripModalOpen(true);
              if (currentTab === 'VEHICLES') setIsVehicleModalOpen(true);
            }}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-full font-medium flex items-center gap-2 transition-all shadow-md hover:shadow-lg active:scale-95"
          >
            <Plus size={20} />
            {currentTab === 'ROOMS' ? t.bookRoom : currentTab === 'TRIPS' ? t.bookTrip : t.bookVehicle}
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        {success && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl flex items-center gap-3 shadow-sm mb-6"
          >
            <Check className="text-emerald-500" />
            {success}
          </motion.div>
        )}

        {currentTab === 'ROOMS' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar - Room List */}
            <aside className="lg:col-span-1 space-y-6">
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <h2 className="text-sm font-semibold uppercase tracking-wider text-gray-500 mb-4 flex items-center gap-2">
                  <MapPin size={16} />
                  {lang === 'vi' ? `Danh sách phòng (${rooms.length})` : `Room List (${rooms.length})`}
                </h2>
                <div className="space-y-3 max-h-[calc(100vh-250px)] overflow-y-auto pr-2 custom-scrollbar">
                  {rooms.map(room => (
                    <div key={room.id} className="p-3 rounded-xl border border-gray-100 hover:border-indigo-200 hover:bg-indigo-50/30 transition-all group">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-semibold text-gray-800 group-hover:text-indigo-700 transition-colors">{room.name}</span>
                        <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full font-medium">{room.location}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Users size={12} />
                          {room.capacity} {lang === 'vi' ? 'người' : 'people'}
                        </span>
                        {room.floor && (
                          <span className="flex items-center gap-1">
                            <Layers size={12} />
                            {lang === 'vi' ? `Tầng ${room.floor}` : `Floor ${room.floor}`}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </aside>

            {/* Main Content - Schedule */}
            <section className="lg:col-span-3 space-y-6">
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                  <h2 className="text-lg font-bold flex items-center gap-2">
                    <Clock className="text-indigo-600" />
                    {lang === 'vi' ? `Lịch họp ngày ${new Date(selectedDate).toLocaleDateString('vi-VN')}` : `Schedule for ${new Date(selectedDate).toLocaleDateString('en-US')}`}
                  </h2>
                  <span className="text-sm text-gray-500">{lang === 'vi' ? `${bookings.length} cuộc họp đã đặt` : `${bookings.length} meetings booked`}</span>
                </div>

                <div className="p-6">
                  {bookings.length === 0 ? (
                    <div className="py-20 text-center space-y-4">
                      <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-300">
                        <Calendar size={32} />
                      </div>
                      <p className="text-gray-400 font-medium">{lang === 'vi' ? 'Chưa có lịch họp nào trong ngày này.' : 'No meetings scheduled for this day.'}</p>
                      <button 
                        onClick={() => setIsBookingModalOpen(true)}
                        className="text-indigo-600 font-semibold hover:underline"
                      >
                        {lang === 'vi' ? 'Bắt đầu đặt phòng ngay' : 'Start booking now'}
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {bookings.map(booking => (
                        <motion.div 
                          key={booking.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex gap-4 group"
                        >
                          <div className="w-24 pt-1 text-right">
                            <div className="text-sm font-bold text-gray-900">
                              {booking.start_time.split(' ')[1].substring(0, 5)}
                            </div>
                            <div className="text-xs text-gray-400">
                              {booking.end_time.split(' ')[1].substring(0, 5)}
                            </div>
                          </div>
                          <div className="flex-1 bg-white border border-gray-100 rounded-2xl p-4 shadow-sm group-hover:shadow-md group-hover:border-indigo-100 transition-all relative overflow-hidden">
                            <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500"></div>
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <h3 className="font-bold text-gray-900">{booking.title}</h3>
                                  {booking.booking_code && (
                                    <span className="text-[10px] bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded font-mono font-bold">
                                      {booking.booking_code}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-wrap gap-4 text-xs text-gray-500">
                                  <span className="flex items-center gap-1">
                                    <Users size={12} />
                                    {booking.participants_count} {lang === 'vi' ? 'người' : 'people'}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <MapPin size={12} />
                                    {booking.room_name}
                                  </span>
                                  <span className="font-medium text-indigo-600">
                                    {lang === 'vi' ? 'Tổ chức:' : 'Organizer:'} {booking.organizer_name}
                                  </span>
                                  {booking.invited_participants.length > 0 && (
                                    <span className="text-gray-400 italic">
                                      {lang === 'vi' ? 'Cùng với:' : 'With:'} {booking.invited_participants.map(p => p.user_name).join(', ')}
                                    </span>
                                  )}
                                </div>
                              </div>
                              
                              {/* RSVP Actions */}
                              {booking.organizer_id !== user.id && booking.user_status === 'PENDING' && (
                                <div className="flex gap-2">
                                  <button 
                                    onClick={() => handleRSVP(booking.id, 'ACCEPTED')}
                                    className="px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold hover:bg-emerald-200 transition-colors flex items-center gap-1"
                                  >
                                    <Check size={14} /> {lang === 'vi' ? 'Chấp nhận' : 'Accept'}
                                  </button>
                                  <button 
                                    onClick={() => handleRSVP(booking.id, 'DECLINED')}
                                    className="px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-xs font-bold hover:bg-red-200 transition-colors flex items-center gap-1"
                                  >
                                    <Plus size={14} className="rotate-45" /> {lang === 'vi' ? 'Từ chối' : 'Decline'}
                                  </button>
                                </div>
                              )}
                              
                              {booking.organizer_id !== user.id && booking.user_status !== 'PENDING' && (
                                <div className={`px-3 py-1.5 rounded-lg text-xs font-bold ${
                                  booking.user_status === 'ACCEPTED' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                                }`}>
                                  {booking.user_status === 'ACCEPTED' ? (lang === 'vi' ? 'Đã chấp nhận' : 'Accepted') : (lang === 'vi' ? 'Đã từ chối' : 'Declined')}
                                </div>
                              )}

                              <div className="flex gap-2 ml-4">
                                <button 
                                  onClick={() => setSelectedBooking(booking)}
                                  className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title={lang === 'vi' ? "Xem chi tiết" : "View Details"}
                                >
                                  <Eye size={18} />
                                </button>
                                {booking.organizer_id === user.id && (
                                  <button 
                                    onClick={() => handleCancelBooking(booking.id)}
                                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                    title={lang === 'vi' ? "Hủy cuộc họp" : "Cancel Meeting"}
                                  >
                                    <Plus size={18} className="rotate-45" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </section>
          </div>
        )}

        {currentTab === 'TRIPS' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <Briefcase className="text-indigo-600" />
                  {t.tripList}
                </h2>
              </div>
              <div className="p-6">
                {trips.length === 0 ? (
                  <div className="py-20 text-center text-gray-400">{t.noTrips}</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {trips.map(trip => (
                      <div key={trip.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-100 space-y-6">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-bold text-lg text-gray-900">{trip.destination}</h3>
                              {trip.booking_code && (
                                <span className="text-[10px] bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded font-mono font-bold">
                                  {trip.booking_code}
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-gray-500">{trip.purpose}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            trip.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {trip.status === 'APPROVED' ? t.approved : t.pending}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Calendar size={16} />
                            {trip.start_date} - {trip.end_date}
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Users size={16} />
                            {trip.participants.length} {lang === 'vi' ? 'người tham gia' : 'participants'}
                          </div>
                        </div>

                        {trip.participants.length > 0 && (
                          <div className="space-y-2">
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{lang === 'vi' ? 'Danh sách người đi' : 'Participant List'}</div>
                            <div className="flex flex-wrap gap-2">
                              {trip.participants.map((p, i) => (
                                <div key={i} className="bg-white px-2 py-1 rounded-lg border border-gray-100 text-[10px] flex flex-col">
                                  <span className="font-bold">{p.name}</span>
                                  <span className="text-gray-400">{p.position}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {trip.rooms.length > 0 && (
                          <div className="space-y-2">
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{lang === 'vi' ? `Phân bổ phòng (${trip.rooms.length} phòng)` : `Room Allocation (${trip.rooms.length} rooms)`}</div>
                            <div className="grid grid-cols-1 gap-2">
                              {trip.rooms.map((r, i) => (
                                <div key={i} className="bg-white p-3 rounded-xl border border-gray-100 flex justify-between items-center">
                                  <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600 font-bold text-xs">
                                      #{r.room_number}
                                    </div>
                                    <div>
                                      <div className="text-xs font-bold">{r.room_type}</div>
                                      <div className="text-[10px] text-gray-400">{r.guest_ids.join(', ')}</div>
                                    </div>
                                  </div>
                                  <Building2 size={16} className="text-gray-300" />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {trip.notes && (
                          <div className="pt-4 border-t border-gray-200">
                            <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">{t.notes}</div>
                            <p className="text-xs text-gray-600 italic">{trip.notes}</p>
                          </div>
                        )}

                        <div className="pt-4 border-t border-gray-200 flex justify-end gap-2">
                          <button 
                            onClick={() => setSelectedTrip(trip)}
                            className="px-3 py-1.5 bg-white border border-gray-200 text-gray-600 rounded-lg text-xs font-bold hover:bg-gray-50 flex items-center gap-1 transition-all"
                          >
                            <Eye size={14} /> {t.details}
                          </button>
                          {trip.user_id === user.id && trip.status === 'PENDING' && (
                            <>
                              <button 
                                onClick={() => handleEditTrip(trip)}
                                className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 flex items-center gap-1 transition-all"
                              >
                                <Search size={14} /> {t.edit}
                              </button>
                              <button 
                                onClick={() => handleCancelTrip(trip.id)}
                                className="px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-bold hover:bg-red-100 flex items-center gap-1 transition-all"
                              >
                                <Plus size={14} className="rotate-45" /> {t.cancel}
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {currentTab === 'VEHICLES' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <Car className="text-indigo-600" />
                  {t.vehicleList}
                </h2>
              </div>
              <div className="p-6">
                {vehicleBookings.length === 0 ? (
                  <div className="py-20 text-center text-gray-400">{t.noVehicles}</div>
                ) : (
                  <div className="space-y-4">
                    {vehicleBookings.map(v => (
                      <div key={v.id} className="flex items-center gap-6 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                        <div className="w-20 text-center">
                          <div className="text-sm font-bold text-gray-900">{v.pickup_time.split(' ')[1].substring(0, 5)}</div>
                          <div className="text-[10px] text-gray-400 uppercase">{v.pickup_time.split(' ')[0]}</div>
                          {v.booking_code && (
                            <div className="mt-1">
                              <span className="text-[9px] bg-indigo-50 text-indigo-600 px-1 py-0.5 rounded font-mono font-bold">
                                {v.booking_code}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex-1 grid grid-cols-4 gap-4">
                          <div>
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{lang === 'vi' ? 'Người đặt' : 'Booked by'}</div>
                            <div className="text-sm font-medium">{v.user_name}</div>
                          </div>
                          <div>
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{t.pickupLocation}</div>
                            <div className="text-sm font-medium">{v.pickup_location}</div>
                          </div>
                          <div>
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{t.destination}</div>
                            <div className="text-sm font-medium">{v.destination}</div>
                          </div>
                          <div>
                            <div className="text-[10px] text-gray-400 uppercase font-bold">{lang === 'vi' ? 'Khách/Người đi cùng' : 'Guests/Passengers'}</div>
                            <div className="text-sm font-medium flex flex-wrap gap-1">
                              {v.invited_participants && v.invited_participants.length > 0 && (
                                v.invited_participants.map(p => (
                                  <span key={p.user_id} className="bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded text-[10px]">
                                    {p.user_name}
                                  </span>
                                ))
                              )}
                              {v.external_participants && v.external_participants.length > 0 && (
                                v.external_participants.map((name, i) => (
                                  <span key={i} className="bg-amber-50 text-amber-600 px-2 py-0.5 rounded text-[10px]">
                                    {name}
                                  </span>
                                ))
                              )}
                              {(!v.invited_participants || v.invited_participants.length === 0) && (!v.external_participants || v.external_participants.length === 0) && (
                                <span className="text-gray-400 italic">{lang === 'vi' ? 'Không có' : 'None'}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold text-center ${
                            v.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {v.status === 'APPROVED' ? t.approved : t.pending}
                          </span>
                          <div className="flex gap-1">
                            <button 
                              onClick={() => setSelectedVehicle(v)}
                              className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                              title={t.details}
                            >
                              <Eye size={16} />
                            </button>
                            {v.user_id === user.id && v.status === 'PENDING' && (
                              <>
                                <button 
                                  onClick={() => handleEditVehicle(v)}
                                  className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title={t.edit}
                                >
                                  <Search size={16} />
                                </button>
                                <button 
                                  onClick={() => handleCancelVehicle(v.id)}
                                  className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                  title={t.cancel}
                                >
                                  <Plus size={16} className="rotate-45" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Booking Modal */}
      <AnimatePresence>
        {isBookingModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsBookingModalOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                  <h2 className="text-2xl font-bold tracking-tight">{t.bookRoom}</h2>
                  <button 
                    onClick={() => setIsBookingModalOpen(false)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <Plus size={24} className="rotate-45 text-gray-400" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Nội dung cuộc họp' : 'Meeting Title'}</label>
                    <input 
                      type="text" 
                      placeholder={lang === 'vi' ? 'Ví dụ: Họp dự án Q1' : 'e.g. Q1 Project Meeting'}
                      className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition-all"
                      value={formData.title}
                      onChange={e => setFormData({...formData, title: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Người tổ chức' : 'Organizer'}</label>
                    <input 
                      type="text" 
                      disabled
                      className="w-full bg-gray-100 border-none rounded-xl px-4 py-3 text-gray-500 cursor-not-allowed"
                      value={formData.organizer}
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Mời người tham gia' : 'Invite Participants'}</label>
                    <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-xl min-h-[50px] max-h-32 overflow-y-auto custom-scrollbar">
                      {users.filter(u => u.id !== user.id).map(u => (
                        <button
                          key={u.id}
                          onClick={() => {
                            const isSelected = formData.invitedUserIds.includes(u.id);
                            setFormData({
                              ...formData,
                              invitedUserIds: isSelected 
                                ? formData.invitedUserIds.filter(id => id !== u.id)
                                : [...formData.invitedUserIds, u.id]
                            });
                          }}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                            formData.invitedUserIds.includes(u.id)
                              ? 'bg-indigo-600 text-white shadow-sm'
                              : 'bg-white text-gray-600 border border-gray-200 hover:border-indigo-300'
                          }`}
                        >
                          {u.name}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Khách mời bên ngoài' : 'External Guests'}</label>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <input 
                          id="external-guest-input"
                          type="text" 
                          placeholder={lang === 'vi' ? 'Nhập tên khách mời...' : 'Enter guest name...'}
                          className="flex-1 bg-gray-50 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 transition-all"
                          onKeyDown={e => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              const input = e.currentTarget;
                              const name = input.value.trim();
                              if (name && !formData.externalParticipants.includes(name)) {
                                setFormData({
                                  ...formData,
                                  externalParticipants: [...formData.externalParticipants, name]
                                });
                                input.value = '';
                              }
                            }
                          }}
                        />
                        <button 
                          onClick={() => {
                            const input = document.getElementById('external-guest-input') as HTMLInputElement;
                            const name = input.value.trim();
                            if (name && !formData.externalParticipants.includes(name)) {
                              setFormData({
                                ...formData,
                                externalParticipants: [...formData.externalParticipants, name]
                              });
                              input.value = '';
                            }
                          }}
                          className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl font-bold text-sm hover:bg-indigo-100 transition-all"
                        >
                          {lang === 'vi' ? 'Thêm' : 'Add'}
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {formData.externalParticipants.map((name, i) => (
                          <span key={i} className="flex items-center gap-1 px-3 py-1 bg-amber-50 text-amber-700 rounded-full text-xs font-medium border border-amber-100">
                            {name}
                            <button 
                              onClick={() => setFormData({
                                ...formData,
                                externalParticipants: formData.externalParticipants.filter((_, idx) => idx !== i)
                              })}
                              className="hover:text-amber-900"
                            >
                              <Plus size={12} className="rotate-45" />
                            </button>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Số lượng người (Tự động)' : 'Number of People (Auto)'}</label>
                    <div className="relative">
                      <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <input 
                        type="number" 
                        readOnly
                        className="w-full bg-gray-100 border-none rounded-xl pl-12 pr-4 py-3 text-gray-500 cursor-not-allowed"
                        value={formData.participants}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Vị trí mong muốn' : 'Desired Location'}</label>
                    <select 
                      className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition-all appearance-none"
                      value={formData.location}
                      onChange={e => setFormData({...formData, location: e.target.value})}
                    >
                      {locations.map(loc => <option key={loc} value={loc}>{loc}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Bắt đầu' : 'Start'}</label>
                      <input 
                        type="time" 
                        className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition-all"
                        value={formData.startTime}
                        onChange={e => setFormData({...formData, startTime: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Kết thúc' : 'End'}</label>
                      <input 
                        type="time" 
                        className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition-all"
                        value={formData.endTime}
                        onChange={e => setFormData({...formData, endTime: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-gray-900">{lang === 'vi' ? 'Gợi ý phòng phù hợp' : 'Suggested Rooms'}</h3>
                    <button 
                      onClick={handleSuggest}
                      disabled={loading}
                      className="text-indigo-600 text-sm font-bold flex items-center gap-1 hover:underline disabled:opacity-50"
                    >
                      <Search size={16} />
                      {loading ? (lang === 'vi' ? "Đang tìm..." : "Searching...") : (lang === 'vi' ? "Tìm phòng trống" : "Find available rooms")}
                    </button>
                  </div>

                  {error && (
                    <div className="bg-red-50 text-red-600 p-3 rounded-xl text-sm flex items-center gap-2 mb-4">
                      <AlertCircle size={16} />
                      {error}
                    </div>
                  )}

                  <div className="grid grid-cols-1 gap-3 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                    {suggestions.map(room => (
                      <button 
                        key={room.id}
                        onClick={() => setFormData({...formData, roomId: room.id})}
                        className={`p-4 rounded-2xl border text-left transition-all flex justify-between items-center ${
                          formData.roomId === room.id 
                            ? 'border-indigo-600 bg-indigo-50 ring-1 ring-indigo-600' 
                            : 'border-gray-100 hover:border-indigo-200 hover:bg-gray-50'
                        }`}
                      >
                        <div>
                          <div className="font-bold text-gray-900">{room.name}</div>
                          <div className="text-xs text-gray-500 flex items-center gap-3 mt-1">
                            <span className="flex items-center gap-1"><Users size={12} /> {room.capacity} {lang === 'vi' ? 'người' : 'people'}</span>
                            <span className="flex items-center gap-1"><MapPin size={12} /> {room.location}</span>
                            {room.floor && (
                              <span className="flex items-center gap-1">
                                <Layers size={12} /> {lang === 'vi' ? `Tầng ${room.floor}` : `Floor ${room.floor}`}
                              </span>
                            )}
                          </div>
                        </div>
                        {formData.roomId === room.id && <Check className="text-indigo-600" size={20} />}
                      </button>
                    ))}
                    {suggestions.length === 0 && !loading && !error && (
                      <div className="text-center py-8 text-gray-400 text-sm border-2 border-dashed border-gray-100 rounded-2xl">
                        {lang === 'vi' ? 'Nhấn "Tìm phòng trống" để xem gợi ý' : 'Click "Find available rooms" to see suggestions'}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setIsBookingModalOpen(false)}
                    className="flex-1 px-6 py-4 rounded-2xl font-bold text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    {t.cancel}
                  </button>
                  <button 
                    onClick={handleBooking}
                    disabled={!formData.roomId || !formData.title || !formData.organizer}
                    className="flex-[2] bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-200 disabled:text-gray-400 text-white px-6 py-4 rounded-2xl font-bold shadow-lg shadow-indigo-200 transition-all active:scale-95"
                  >
                    {lang === 'vi' ? 'Xác nhận đặt phòng' : 'Confirm Booking'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Trip Modal */}
      <AnimatePresence>
        {isTripModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsTripModalOpen(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white sticky top-0 z-10">
                <div className="flex justify-between items-center mb-8">
                  <h2 className="text-2xl font-bold tracking-tight">
                    {editingTripId ? (lang === 'vi' ? "Chỉnh sửa yêu cầu công tác" : "Edit Business Trip") : (lang === 'vi' ? "Đăng ký công tác" : "Business Trip Registration")}
                  </h2>
                </div>
                <button onClick={() => setIsTripModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <Plus size={24} className="rotate-45 text-gray-400" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                <div className="space-y-10">
                  {/* 1. Trip Information */}
                  <section>
                    <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-widest mb-6 flex items-center gap-2">
                      <span className="w-6 h-6 bg-indigo-100 rounded-lg flex items-center justify-center text-[10px]">1</span>
                      {lang === 'vi' ? 'Thông tin chuyến công tác' : 'Trip Information'}
                    </h3>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{t.destination}</label>
                        <input type="text" placeholder={lang === 'vi' ? "Ví dụ: TP. Hồ Chí Minh" : "e.g. Ho Chi Minh City"} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500" value={tripFormData.destination} onChange={e => setTripFormData({...tripFormData, destination: e.target.value})} />
                      </div>
                      <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Mục đích' : 'Purpose'}</label>
                        <input type="text" placeholder={lang === 'vi' ? "Ví dụ: Họp đối tác" : "e.g. Partner Meeting"} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500" value={tripFormData.purpose} onChange={e => setTripFormData({...tripFormData, purpose: e.target.value})} />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Ngày đi' : 'Start Date'}</label>
                        <input type="date" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3" value={tripFormData.startDate} onChange={e => setTripFormData({...tripFormData, startDate: e.target.value})} />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Ngày về' : 'End Date'}</label>
                        <input type="date" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3" value={tripFormData.endDate} onChange={e => setTripFormData({...tripFormData, endDate: e.target.value})} />
                      </div>
                    </div>
                  </section>

                  {/* 2. Participants */}
                  <section>
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-widest flex items-center gap-2">
                        <span className="w-6 h-6 bg-indigo-100 rounded-lg flex items-center justify-center text-[10px]">2</span>
                        {lang === 'vi' ? 'Danh sách người tham gia' : 'Participant List'}
                      </h3>
                      <button onClick={addParticipant} className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors">
                        <Plus size={14} /> {lang === 'vi' ? 'Thêm người tham gia' : 'Add Participant'}
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-gray-100">
                            <th className="pb-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{lang === 'vi' ? 'Họ tên' : 'Full Name'}</th>
                            <th className="pb-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{lang === 'vi' ? 'Chức vụ' : 'Position'}</th>
                            <th className="pb-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{lang === 'vi' ? 'Phòng ban' : 'Department'}</th>
                            <th className="pb-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider">{lang === 'vi' ? 'Số điện thoại' : 'Phone'}</th>
                            <th className="pb-3"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {tripFormData.participants.map((p, idx) => (
                            <tr key={idx}>
                              <td className="py-3 pr-4">
                                <input type="text" className="w-full bg-gray-50 border-none rounded-lg px-3 py-2 text-sm" value={p.name} onChange={e => {
                                  const newP = [...tripFormData.participants];
                                  newP[idx].name = e.target.value;
                                  setTripFormData({...tripFormData, participants: newP});
                                }} />
                              </td>
                              <td className="py-3 pr-4">
                                <input type="text" className="w-full bg-gray-50 border-none rounded-lg px-3 py-2 text-sm" value={p.position} onChange={e => {
                                  const newP = [...tripFormData.participants];
                                  newP[idx].position = e.target.value;
                                  setTripFormData({...tripFormData, participants: newP});
                                }} />
                              </td>
                              <td className="py-3 pr-4">
                                <input type="text" className="w-full bg-gray-50 border-none rounded-lg px-3 py-2 text-sm" value={p.department} onChange={e => {
                                  const newP = [...tripFormData.participants];
                                  newP[idx].department = e.target.value;
                                  setTripFormData({...tripFormData, participants: newP});
                                }} />
                              </td>
                              <td className="py-3 pr-4">
                                <input type="text" className="w-full bg-gray-50 border-none rounded-lg px-3 py-2 text-sm" value={p.phone} onChange={e => {
                                  const newP = [...tripFormData.participants];
                                  newP[idx].phone = e.target.value;
                                  setTripFormData({...tripFormData, participants: newP});
                                }} />
                              </td>
                              <td className="py-3 text-right">
                                {tripFormData.participants.length > 1 && (
                                  <button onClick={() => removeParticipant(idx)} className="text-red-400 hover:text-red-600 p-1">
                                    <Plus size={18} className="rotate-45" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div className="mt-4 text-xs text-gray-500 font-medium">
                      {lang === 'vi' ? 'Tổng số người:' : 'Total People:'} <span className="text-indigo-600 font-bold">{tripFormData.participants.length}</span>
                    </div>
                  </section>

                  {/* 3. Followers */}
                  <section>
                    <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-widest mb-6 flex items-center gap-2">
                      <span className="w-6 h-6 bg-indigo-100 rounded-lg flex items-center justify-center text-[10px]">3</span>
                      {lang === 'vi' ? 'Người theo dõi (Followers)' : 'Followers'}
                    </h3>
                    <div className="flex flex-wrap gap-2 p-4 bg-gray-50 rounded-2xl min-h-[60px] max-h-40 overflow-y-auto custom-scrollbar border border-gray-100">
                      {users.filter(u => u.id !== user.id).map(u => (
                        <button
                          key={u.id}
                          onClick={() => {
                            const isSelected = tripFormData.followers.includes(u.id);
                            setTripFormData({
                              ...tripFormData,
                              followers: isSelected 
                                ? tripFormData.followers.filter(id => id !== u.id)
                                : [...tripFormData.followers, u.id]
                            });
                          }}
                          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                            tripFormData.followers.includes(u.id)
                              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100'
                              : 'bg-white text-gray-600 border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/30'
                          }`}
                        >
                          {u.name}
                          {tripFormData.followers.includes(u.id) && <Check size={14} />}
                        </button>
                      ))}
                    </div>
                    <p className="mt-3 text-[10px] text-gray-400 italic">{lang === 'vi' ? 'Chọn những người liên quan để họ nhận được thông tin về chuyến công tác này.' : 'Select relevant people to receive information about this business trip.'}</p>
                  </section>

                  {/* 4. Hotel Booking */}
                  <section>
                    <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-widest mb-6 flex items-center gap-2">
                      <span className="w-6 h-6 bg-indigo-100 rounded-lg flex items-center justify-center text-[10px]">4</span>
                      {lang === 'vi' ? 'Đặt phòng khách sạn' : 'Hotel Booking'}
                    </h3>
                    <div className="grid grid-cols-3 gap-6 mb-8">
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Thành phố' : 'City'}</label>
                        <input type="text" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm" value={tripFormData.city} onChange={e => setTripFormData({...tripFormData, city: e.target.value})} />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Check-in</label>
                        <input type="date" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm" value={tripFormData.hotelCheckIn} onChange={e => setTripFormData({...tripFormData, hotelCheckIn: e.target.value})} />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Check-out</label>
                        <input type="date" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm" value={tripFormData.hotelCheckOut} onChange={e => setTripFormData({...tripFormData, hotelCheckOut: e.target.value})} />
                      </div>
                    </div>

                    <div className="flex justify-between items-center mb-4">
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">{lang === 'vi' ? 'Danh sách phòng' : 'Room List'}</label>
                      <button onClick={addRoom} className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors">
                        <Plus size={14} /> {lang === 'vi' ? 'Thêm phòng' : 'Add Room'}
                      </button>
                    </div>
                    <div className="space-y-3">
                      {tripFormData.rooms.map((room, idx) => (
                        <div key={idx} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                          <div className="w-20">
                            <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">{lang === 'vi' ? 'Phòng' : 'Room'}</div>
                            <div className="font-bold text-sm">#{room.room_number}</div>
                          </div>
                          <div className="flex-1">
                            <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">{lang === 'vi' ? 'Loại phòng' : 'Room Type'}</div>
                            <select className="w-full bg-white border-none rounded-lg px-3 py-2 text-sm" value={room.room_type} onChange={e => {
                              const newRooms = [...tripFormData.rooms];
                              newRooms[idx].room_type = e.target.value as any;
                              setTripFormData({...tripFormData, rooms: newRooms});
                            }}>
                              <option value="Single">Single</option>
                              <option value="Twin">Twin</option>
                            </select>
                          </div>
                          <div className="flex-[2]">
                            <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">{lang === 'vi' ? 'Khách ở' : 'Guests'}</div>
                            <div className="space-y-2">
                              {/* Selected Guests Tags */}
                              <div className="flex flex-wrap gap-1.5 min-h-[32px] p-1 bg-white rounded-lg border border-gray-100">
                                {room.guest_ids.length > 0 ? (
                                  room.guest_ids.map(guestName => (
                                    <span 
                                      key={guestName} 
                                      className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-50 text-indigo-700 rounded text-[10px] font-bold border border-indigo-100"
                                    >
                                      {guestName}
                                      <button 
                                        onClick={() => {
                                          const newRooms = [...tripFormData.rooms];
                                          newRooms[idx].guest_ids = newRooms[idx].guest_ids.filter(name => name !== guestName);
                                          setTripFormData({...tripFormData, rooms: newRooms});
                                        }}
                                        className="hover:text-indigo-900 transition-colors"
                                      >
                                        <Plus size={12} className="rotate-45" />
                                      </button>
                                    </span>
                                  ))
                                ) : (
                                  <span className="text-[10px] text-gray-300 italic px-2 py-1">{lang === 'vi' ? 'Chưa chọn khách' : 'No guests selected'}</span>
                                )}
                              </div>

                              {/* Selection Pool */}
                              <div className="flex flex-wrap gap-1">
                                {tripFormData.participants
                                  .filter(p => p.name && !room.guest_ids.includes(p.name))
                                  .map(p => {
                                    const isAssignedElsewhere = tripFormData.rooms.some((r, rIdx) => rIdx !== idx && r.guest_ids.includes(p.name));
                                    return (
                                      <button 
                                        key={p.name}
                                        onClick={() => {
                                          const newRooms = [...tripFormData.rooms];
                                          newRooms[idx].guest_ids = [...newRooms[idx].guest_ids, p.name];
                                          setTripFormData({...tripFormData, rooms: newRooms});
                                        }}
                                        className={`px-2 py-1 rounded text-[10px] font-medium transition-colors border ${
                                          isAssignedElsewhere 
                                            ? 'bg-amber-50 text-amber-600 border-amber-100 hover:bg-amber-100' 
                                            : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                                        }`}
                                        title={isAssignedElsewhere ? (lang === 'vi' ? 'Đã được xếp vào phòng khác' : 'Already assigned to another room') : (lang === 'vi' ? 'Chọn khách' : 'Select guest')}
                                      >
                                        + {p.name}
                                      </button>
                                    );
                                  })}
                                {tripFormData.participants.every(p => !p.name) && (
                                  <span className="text-[10px] text-gray-400 italic">{lang === 'vi' ? 'Nhập tên người tham gia trước' : 'Enter participant names first'}</span>
                                )}
                              </div>
                            </div>
                          </div>
                          {tripFormData.rooms.length > 1 && (
                            <button onClick={() => removeRoom(idx)} className="text-red-400 hover:text-red-600 p-1">
                              <Plus size={18} className="rotate-45" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </section>

                  {/* 5. Additional Notes */}
                  <section>
                    <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-widest mb-4 flex items-center gap-2">
                      <span className="w-6 h-6 bg-indigo-100 rounded-lg flex items-center justify-center text-[10px]">5</span>
                      {t.notes}
                    </h3>
                    <textarea rows={3} placeholder={lang === 'vi' ? "Nhập các yêu cầu đặc biệt khác..." : "Enter other special requests..."} className="w-full bg-gray-50 border-none rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500" value={tripFormData.notes} onChange={e => setTripFormData({...tripFormData, notes: e.target.value})} />
                  </section>
                </div>
              </div>

              <div className="p-6 border-t border-gray-100 bg-white flex gap-4">
                <button onClick={() => {
                  setIsTripModalOpen(false);
                  setEditingTripId(null);
                }} className="flex-1 px-6 py-4 rounded-2xl font-bold text-gray-500 hover:bg-gray-50 transition-colors">{t.cancel}</button>
                <button onClick={handleTripBooking} className="flex-[2] bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-4 rounded-2xl font-bold shadow-lg shadow-indigo-200 transition-all active:scale-95">
                  {editingTripId ? (lang === 'vi' ? "Cập nhật yêu cầu" : "Update Request") : (lang === 'vi' ? "Gửi yêu cầu công tác" : "Submit Trip Request")}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Vehicle Modal */}
      <AnimatePresence>
        {isVehicleModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsVehicleModalOpen(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden">
              <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                  <h2 className="text-2xl font-bold tracking-tight">
                    {editingVehicleId ? (lang === 'vi' ? "Chỉnh sửa đặt xe" : "Edit Vehicle Booking") : t.bookVehicle}
                  </h2>
                  <button onClick={() => {
                    setIsVehicleModalOpen(false);
                    setEditingVehicleId(null);
                  }} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <Plus size={24} className="rotate-45 text-gray-400" />
                  </button>
                </div>

                <div className="space-y-6 mb-8">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{t.pickupLocation}</label>
                    <input type="text" placeholder={lang === 'vi' ? "Ví dụ: Văn phòng A" : "e.g. Office A"} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500" value={vehicleFormData.pickupLocation} onChange={e => setVehicleFormData({...vehicleFormData, pickupLocation: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{t.destination}</label>
                    <input type="text" placeholder={lang === 'vi' ? "Ví dụ: Khách hàng B" : "e.g. Client B"} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500" value={vehicleFormData.destination} onChange={e => setVehicleFormData({...vehicleFormData, destination: e.target.value})} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Ngày đón' : 'Pickup Date'}</label>
                      <input type="date" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3" value={vehicleFormData.date} onChange={e => setVehicleFormData({...vehicleFormData, date: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Giờ đón' : 'Pickup Time'}</label>
                      <input type="time" className="w-full bg-gray-50 border-none rounded-xl px-4 py-3" value={vehicleFormData.pickupTime} onChange={e => setVehicleFormData({...vehicleFormData, pickupTime: e.target.value})} />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Người đi cùng' : 'Passengers'}</label>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {users.filter(u => u.id !== user?.id).map(u => (
                        <button 
                          key={u.id}
                          onClick={() => {
                            const newIds = vehicleFormData.invitedUserIds.includes(u.id)
                              ? vehicleFormData.invitedUserIds.filter(id => id !== u.id)
                              : [...vehicleFormData.invitedUserIds, u.id];
                            setVehicleFormData({
                              ...vehicleFormData, 
                              invitedUserIds: newIds,
                              passengers: newIds.length + vehicleFormData.externalParticipants.length + 1
                            });
                          }}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                            vehicleFormData.invitedUserIds.includes(u.id)
                              ? 'bg-indigo-600 text-white shadow-sm'
                              : 'bg-white text-gray-600 border border-gray-200 hover:border-indigo-300'
                          }`}
                        >
                          {u.name}
                        </button>
                      ))}
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">{lang === 'vi' ? 'Khách đi cùng' : 'External Guests'}</label>
                      <div className="flex gap-2">
                        <input 
                          id="guest-input"
                          type="text" 
                          placeholder={lang === 'vi' ? "Nhập tên khách..." : "Enter guest name..."} 
                          className="flex-1 bg-gray-50 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              const input = e.currentTarget;
                              const name = input.value.trim();
                              if (name && !vehicleFormData.externalParticipants.includes(name)) {
                                const newExternal = [...vehicleFormData.externalParticipants, name];
                                setVehicleFormData({
                                  ...vehicleFormData,
                                  externalParticipants: newExternal,
                                  passengers: vehicleFormData.invitedUserIds.length + newExternal.length + 1
                                });
                                input.value = '';
                              }
                              e.preventDefault();
                            }
                          }}
                        />
                        <button 
                          onClick={() => {
                            const input = document.getElementById('guest-input') as HTMLInputElement;
                            const name = input.value.trim();
                            if (name && !vehicleFormData.externalParticipants.includes(name)) {
                              const newExternal = [...vehicleFormData.externalParticipants, name];
                              setVehicleFormData({
                                ...vehicleFormData,
                                externalParticipants: newExternal,
                                passengers: vehicleFormData.invitedUserIds.length + newExternal.length + 1
                              });
                              input.value = '';
                            }
                          }}
                          className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-colors"
                        >
                          {lang === 'vi' ? 'Thêm khách' : 'Add Guest'}
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {vehicleFormData.externalParticipants.map(name => (
                          <span key={name} className="inline-flex items-center gap-1 px-2 py-1 bg-amber-50 text-amber-700 rounded text-[10px] font-bold border border-amber-100">
                            {name}
                            <button 
                              onClick={() => {
                                const newExternal = vehicleFormData.externalParticipants.filter(n => n !== name);
                                setVehicleFormData({
                                  ...vehicleFormData,
                                  externalParticipants: newExternal,
                                  passengers: vehicleFormData.invitedUserIds.length + newExternal.length + 1
                                });
                              }}
                            >
                              <Plus size={12} className="rotate-45" />
                            </button>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{lang === 'vi' ? 'Tổng số người' : 'Total People'}</label>
                    <div className="relative">
                      <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <input type="number" min="1" className="w-full bg-gray-50 border-none rounded-xl pl-12 pr-4 py-3 focus:ring-2 focus:ring-indigo-500" value={vehicleFormData.passengers} readOnly />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button onClick={() => {
                    setIsVehicleModalOpen(false);
                    setEditingVehicleId(null);
                  }} className="flex-1 px-6 py-4 rounded-2xl font-bold text-gray-500 hover:bg-gray-50 transition-colors">{t.cancel}</button>
                  <button onClick={handleVehicleBooking} className="flex-[2] bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-4 rounded-2xl font-bold shadow-lg shadow-indigo-200 transition-all active:scale-95">
                    {editingVehicleId ? (lang === 'vi' ? "Cập nhật yêu cầu" : "Update Request") : (lang === 'vi' ? "Xác nhận đặt xe" : "Confirm Booking")}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      {/* Booking Detail Modal */}
      <AnimatePresence>
        {selectedBooking && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedBooking(null)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden">
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h2 className="text-xl font-bold">{lang === 'vi' ? 'Chi tiết cuộc họp' : 'Meeting Details'}</h2>
                    {selectedBooking.booking_code && (
                      <span className="text-[10px] text-indigo-600 font-mono font-bold">{selectedBooking.booking_code}</span>
                    )}
                  </div>
                  <button onClick={() => setSelectedBooking(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <Plus size={20} className="rotate-45 text-gray-400" />
                  </button>
                </div>
                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{t.meetingTitle}</label>
                    <p className="font-bold text-gray-900">{selectedBooking.title}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{lang === 'vi' ? 'Phòng' : 'Room'}</label>
                      <p className="text-sm font-medium">{selectedBooking.room_name}</p>
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{lang === 'vi' ? 'Số người' : 'People'}</label>
                      <p className="text-sm font-medium">{selectedBooking.participants_count} {lang === 'vi' ? 'người' : 'people'}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{t.start}</label>
                      <p className="text-sm font-medium">{selectedBooking.start_time}</p>
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{t.end}</label>
                      <p className="text-sm font-medium">{selectedBooking.end_time}</p>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{t.organizer}</label>
                    <p className="text-sm font-medium text-indigo-600">{selectedBooking.organizer_name}</p>
                  </div>
                  {selectedBooking.invited_participants.length > 0 && (
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{lang === 'vi' ? 'Người tham gia nội bộ' : 'Internal Participants'}</label>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {selectedBooking.invited_participants.map(p => (
                          <span key={p.user_id} className={`px-2 py-1 rounded text-[10px] font-bold ${
                            p.status === 'ACCEPTED' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                            p.status === 'DECLINED' ? 'bg-red-50 text-red-600 border border-red-100' :
                            'bg-gray-50 text-gray-500 border border-gray-200'
                          }`}>
                            {p.user_name} ({p.status === 'ACCEPTED' ? (lang === 'vi' ? 'Đã nhận' : 'Accepted') : p.status === 'DECLINED' ? (lang === 'vi' ? 'Từ chối' : 'Declined') : (lang === 'vi' ? 'Chờ' : 'Pending')})
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedBooking.external_participants && selectedBooking.external_participants.length > 0 && (
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{t.externalGuests}</label>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {selectedBooking.external_participants.map((name, i) => (
                          <span key={i} className="px-2 py-1 rounded text-[10px] font-bold bg-amber-50 text-amber-600 border border-amber-100">
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <button onClick={() => setSelectedBooking(null)} className="w-full mt-8 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-xl font-bold transition-all">{lang === 'vi' ? 'Đóng' : 'Close'}</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Trip Detail Modal */}
      <AnimatePresence>
        {selectedTrip && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedTrip(null)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold">{lang === 'vi' ? 'Chi tiết yêu cầu công tác' : 'Trip Request Details'}</h2>
                  {selectedTrip.booking_code && (
                    <span className="text-[10px] text-indigo-600 font-mono font-bold">{selectedTrip.booking_code}</span>
                  )}
                </div>
                <button onClick={() => setSelectedTrip(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <Plus size={20} className="rotate-45 text-gray-400" />
                </button>
              </div>
              <div className="p-8 overflow-y-auto custom-scrollbar space-y-8">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{selectedTrip.destination}</h3>
                    <p className="text-gray-500">{selectedTrip.purpose}</p>
                  </div>
                  <span className={`px-4 py-1.5 rounded-full text-sm font-bold ${
                    selectedTrip.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {selectedTrip.status === 'APPROVED' ? (lang === 'vi' ? 'Đã duyệt' : 'Approved') : (lang === 'vi' ? 'Đang chờ phê duyệt' : 'Pending Approval')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Thông tin chung' : 'General Information'}</h4>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 text-sm">
                        <Calendar size={16} className="text-gray-400" />
                        <span className="text-gray-600">{lang === 'vi' ? 'Thời gian:' : 'Duration:'} </span>
                        <span className="font-bold">{selectedTrip.start_date} {lang === 'vi' ? 'đến' : 'to'} {selectedTrip.end_date}</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <MapPin size={16} className="text-gray-400" />
                        <span className="text-gray-600">{lang === 'vi' ? 'Thành phố:' : 'City:'} </span>
                        <span className="font-bold">{selectedTrip.city || (lang === 'vi' ? 'Chưa cập nhật' : 'N/A')}</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Khách sạn' : 'Hotel'}</h4>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 text-sm">
                        <Building2 size={16} className="text-gray-400" />
                        <span className="text-gray-600">Check-in: </span>
                        <span className="font-bold">{selectedTrip.hotel_check_in || 'N/A'}</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <Building2 size={16} className="text-gray-400" />
                        <span className="text-gray-600">Check-out: </span>
                        <span className="font-bold">{selectedTrip.hotel_check_out || 'N/A'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Danh sách người đi' : 'Participant List'} ({selectedTrip.participants.length})</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {selectedTrip.participants.map((p, i) => (
                      <div key={i} className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center gap-3">
                        <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-indigo-600 font-bold text-xs border border-gray-100">
                          {p.name.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-bold">{p.name}</div>
                          <div className="text-[10px] text-gray-400">{p.position} - {p.department}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedTrip.rooms.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Phân bổ phòng' : 'Room Allocation'} ({selectedTrip.rooms.length} {lang === 'vi' ? 'phòng' : 'rooms'})</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {selectedTrip.rooms.map((r, i) => (
                        <div key={i} className="p-4 bg-white rounded-2xl border border-gray-100 shadow-sm">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-xs font-bold text-indigo-600">{lang === 'vi' ? 'Phòng' : 'Room'} #{r.room_number}</span>
                            <span className="text-[10px] bg-gray-100 px-2 py-0.5 rounded-full">{r.room_type}</span>
                          </div>
                          <div className="text-sm font-medium text-gray-700">
                            {lang === 'vi' ? 'Khách:' : 'Guests:'} {r.guest_ids.join(', ')}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedTrip.status === 'APPROVED' && (
                  <div className="space-y-4 bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100">
                    <div className="flex items-center gap-2 mb-2">
                      <Building2 size={20} className="text-indigo-600" />
                      <h4 className="text-sm font-bold text-indigo-900 uppercase tracking-widest">
                        {lang === 'vi' ? 'KẾT QUẢ BOOKING KHÁCH SẠN' : 'HOTEL BOOKING RESULT'}
                      </h4>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="bg-white rounded-2xl overflow-hidden border border-indigo-100">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-indigo-50/50 text-indigo-900 text-[10px] uppercase font-bold">
                              <th className="px-4 py-2 text-left border-b border-indigo-100">{lang === 'vi' ? 'Nội dung' : 'Content'}</th>
                              <th className="px-4 py-2 text-left border-b border-indigo-100">{lang === 'vi' ? 'Chi tiết' : 'Details'}</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-indigo-50">
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Mã đơn công tác' : 'Booking Code'}</td>
                              <td className="px-4 py-2 font-bold text-indigo-600 font-mono">{selectedTrip.booking_code}</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Người đề xuất' : 'Proposer'}</td>
                              <td className="px-4 py-2 font-bold text-gray-900">{selectedTrip.user_name}</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Trạng thái' : 'Status'}</td>
                              <td className="px-4 py-2">
                                <span className="text-emerald-600 font-bold flex items-center gap-1">
                                  <Check size={14} /> {lang === 'vi' ? 'Đã đặt phòng' : 'Booked'}
                                </span>
                              </td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Khách sạn' : 'Hotel'}</td>
                              <td className="px-4 py-2 font-bold text-gray-900">{selectedTrip.hotel_name || (lang === 'vi' ? 'Chưa cập nhật' : 'N/A')}</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Địa điểm' : 'Location'}</td>
                              <td className="px-4 py-2 font-bold text-gray-900">{selectedTrip.hotel_location || (lang === 'vi' ? 'Chưa cập nhật' : 'N/A')}</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">Check-in</td>
                              <td className="px-4 py-2 font-bold text-gray-900">{selectedTrip.hotel_check_in}</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">Check-out</td>
                              <td className="px-4 py-2 font-bold text-gray-900">{selectedTrip.hotel_check_out}</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Tổng số đêm' : 'Total Nights'}</td>
                              <td className="px-4 py-2 font-bold text-gray-900">
                                {(() => {
                                  if (!selectedTrip.hotel_check_in || !selectedTrip.hotel_check_out) return 0;
                                  const start = new Date(selectedTrip.hotel_check_in);
                                  const end = new Date(selectedTrip.hotel_check_out);
                                  const diffTime = Math.abs(end.getTime() - start.getTime());
                                  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                                })()} {lang === 'vi' ? 'đêm' : 'nights'}
                              </td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2 font-medium text-gray-500">{lang === 'vi' ? 'Tổng số phòng' : 'Total Rooms'}</td>
                              <td className="px-4 py-2 font-bold text-gray-900">{selectedTrip.rooms.length} {lang === 'vi' ? 'phòng' : 'rooms'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 uppercase tracking-widest">
                          <span>🏨</span> {lang === 'vi' ? 'Danh sách phòng đã đặt' : 'Booked Room List'}
                        </div>
                        <div className="bg-white rounded-2xl overflow-hidden border border-indigo-100">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="bg-indigo-50/30 text-indigo-900 text-[10px] uppercase font-bold">
                                <th className="px-4 py-2 text-left border-b border-indigo-100">{lang === 'vi' ? 'Phòng' : 'Room'}</th>
                                <th className="px-4 py-2 text-left border-b border-indigo-100">{lang === 'vi' ? 'Loại phòng' : 'Room Type'}</th>
                                <th className="px-4 py-2 text-left border-b border-indigo-100">{lang === 'vi' ? 'Người ở' : 'Occupants'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-indigo-50">
                              {selectedTrip.rooms.map((r, i) => (
                                <tr key={i}>
                                  <td className="px-4 py-2 font-bold text-gray-900">#{r.room_number}</td>
                                  <td className="px-4 py-2 text-gray-600">{r.room_type}</td>
                                  <td className="px-4 py-2 text-gray-600">{r.guest_ids.join(', ')}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      {selectedTrip.hr_comment && (
                        <div className="space-y-1">
                          <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Ghi chú từ HR' : 'Notes from HR'}</div>
                          <div className="bg-white p-4 rounded-2xl border border-indigo-100 text-sm italic text-gray-600">
                            {selectedTrip.hr_comment}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {selectedTrip.notes && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{t.notes}</h4>
                    <p className="text-sm text-gray-600 bg-gray-50 p-4 rounded-2xl italic">{selectedTrip.notes}</p>
                  </div>
                )}

                <div className="pt-8 border-t border-gray-100">
                  <Workflow 
                    status={selectedTrip.status} 
                    createdAt={selectedTrip.created_at} 
                    processedAt={selectedTrip.processed_at} 
                    hrComment={selectedTrip.hr_comment} 
                    type="TRIP"
                    lang={lang}
                  />
                </div>

                {user?.role === 'HR_MANAGER' && selectedTrip.status === 'PENDING' && (
                  <div className="pt-8 border-t border-gray-100 space-y-4">
                    <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Xử lý yêu cầu (Dành cho HR)' : 'Process Request (For HR)'}</h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{lang === 'vi' ? 'Khách sạn' : 'Hotel Name'}</label>
                        <input 
                          id="hotel-name-trip"
                          type="text"
                          placeholder={lang === 'vi' ? "Nhập tên khách sạn..." : "Enter hotel name..."} 
                          className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-gray-400 uppercase font-bold block mb-1">{lang === 'vi' ? 'Địa điểm' : 'Location'}</label>
                        <input 
                          id="hotel-location-trip"
                          type="text"
                          placeholder={lang === 'vi' ? "Nhập địa chỉ/vị trí..." : "Enter address/location..."} 
                          className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                    </div>

                    <textarea 
                      id="hr-comment-trip"
                      placeholder={lang === 'vi' ? "Nhập phản hồi hoặc lý do từ chối..." : "Enter feedback or reason for rejection..."} 
                      className="w-full bg-gray-50 border-none rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                    />
                    <div className="flex gap-4">
                      <button 
                        onClick={async () => {
                          const comment = (document.getElementById('hr-comment-trip') as HTMLTextAreaElement).value;
                          const hotel_name = (document.getElementById('hotel-name-trip') as HTMLInputElement).value;
                          const hotel_location = (document.getElementById('hotel-location-trip') as HTMLInputElement).value;
                          const res = await fetch(`/api/trips/${selectedTrip.id}/approve`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ hr_id: user.id, comment, hotel_name, hotel_location })
                          });
                          if (res.ok) {
                            setSuccess(lang === 'vi' ? "Đã phê duyệt yêu cầu!" : "Request approved!");
                            loadTrips();
                            setSelectedTrip(null);
                          }
                        }}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-emerald-200 transition-all"
                      >
                        {lang === 'vi' ? 'Phê duyệt' : 'Approve'}
                      </button>
                      <button 
                        onClick={async () => {
                          const comment = (document.getElementById('hr-comment-trip') as HTMLTextAreaElement).value;
                          if (!comment) return alert(lang === 'vi' ? "Vui lòng nhập lý do từ chối" : "Please enter a reason for rejection");
                          const res = await fetch(`/api/trips/${selectedTrip.id}/reject`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ hr_id: user.id, comment })
                          });
                          if (res.ok) {
                            setSuccess(lang === 'vi' ? "Đã từ chối yêu cầu!" : "Request rejected!");
                            loadTrips();
                            setSelectedTrip(null);
                          }
                        }}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-red-200 transition-all"
                      >
                        {lang === 'vi' ? 'Từ chối' : 'Reject'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
              <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end">
                <button onClick={() => setSelectedTrip(null)} className="px-8 py-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-100 transition-all">{lang === 'vi' ? 'Đóng' : 'Close'}</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Vehicle Detail Modal */}
      <AnimatePresence>
        {selectedVehicle && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedVehicle(null)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden">
              <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h2 className="text-xl font-bold">{lang === 'vi' ? 'Chi tiết đặt xe' : 'Vehicle Booking Details'}</h2>
                    {selectedVehicle.booking_code && (
                      <span className="text-[10px] text-indigo-600 font-mono font-bold">{selectedVehicle.booking_code}</span>
                    )}
                  </div>
                  <button onClick={() => setSelectedVehicle(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <Plus size={20} className="rotate-45 text-gray-400" />
                  </button>
                </div>
                
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <span className={`px-4 py-1.5 rounded-full text-xs font-bold ${
                      selectedVehicle.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {selectedVehicle.status === 'APPROVED' ? (lang === 'vi' ? 'Đã duyệt' : 'Approved') : (lang === 'vi' ? 'Đang chờ phê duyệt' : 'Pending Approval')}
                    </span>
                    <div className="text-right">
                      <div className="text-lg font-bold text-gray-900">{selectedVehicle.pickup_time.split(' ')[1].substring(0, 5)}</div>
                      <div className="text-xs text-gray-400">{selectedVehicle.pickup_time.split(' ')[0]}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                      <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">{t.pickupLocation}</div>
                      <div className="font-bold text-gray-900 flex items-center gap-2">
                        <MapPin size={14} className="text-indigo-500" />
                        {selectedVehicle.pickup_location}
                      </div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                      <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">{t.destination}</div>
                      <div className="font-bold text-gray-900 flex items-center gap-2">
                        <MapPin size={14} className="text-emerald-500" />
                        {selectedVehicle.destination}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-gray-400 uppercase font-bold block mb-2">{lang === 'vi' ? 'Người đi cùng' : 'Passengers'} ({selectedVehicle.passengers} {lang === 'vi' ? 'người' : 'people'})</label>
                    <div className="space-y-2">
                      {selectedVehicle.invited_participants.map(p => (
                        <div key={p.user_id} className="flex items-center gap-2 text-sm bg-indigo-50 text-indigo-700 px-3 py-2 rounded-xl">
                          <Users size={14} />
                          {p.user_name} ({lang === 'vi' ? 'Nội bộ' : 'Internal'})
                        </div>
                      ))}
                      {selectedVehicle.external_participants.map((name, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm bg-amber-50 text-amber-700 px-3 py-2 rounded-xl">
                          <Users size={14} />
                          {name} ({lang === 'vi' ? 'Khách ngoài' : 'External'})
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-8 border-t border-gray-100">
                    <Workflow 
                      status={selectedVehicle.status} 
                      createdAt={selectedVehicle.created_at} 
                      processedAt={selectedVehicle.processed_at} 
                      hrComment={selectedVehicle.hr_comment} 
                      type="VEHICLE"
                      lang={lang}
                    />
                  </div>

                  {user?.role === 'HR_MANAGER' && selectedVehicle.status === 'PENDING' && (
                    <div className="pt-8 border-t border-gray-100 space-y-4">
                      <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{lang === 'vi' ? 'Xử lý yêu cầu (Dành cho Khối HCTH-DVHS)' : 'Process Request (For Admin Dept)'}</h4>
                      <textarea 
                        id="hr-comment-vehicle"
                        placeholder={lang === 'vi' ? "Nhập phản hồi hoặc lý do từ chối..." : "Enter feedback or reason for rejection..."} 
                        className="w-full bg-gray-50 border-none rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      />
                      <div className="flex gap-4">
                        <button 
                          onClick={async () => {
                            const comment = (document.getElementById('hr-comment-vehicle') as HTMLTextAreaElement).value;
                            const res = await fetch(`/api/vehicles/${selectedVehicle.id}/approve`, {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ hr_id: user.id, comment })
                            });
                            if (res.ok) {
                              setSuccess(lang === 'vi' ? "Đã phê duyệt yêu cầu!" : "Request approved!");
                              loadVehicleBookings();
                              setSelectedVehicle(null);
                            }
                          }}
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-emerald-200 transition-all"
                        >
                          {lang === 'vi' ? 'Phê duyệt' : 'Approve'}
                        </button>
                        <button 
                          onClick={async () => {
                            const comment = (document.getElementById('hr-comment-vehicle') as HTMLTextAreaElement).value;
                            if (!comment) return alert(lang === 'vi' ? "Vui lòng nhập lý do từ chối" : "Please enter a reason for rejection");
                            const res = await fetch(`/api/vehicles/${selectedVehicle.id}/reject`, {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ hr_id: user.id, comment })
                            });
                            if (res.ok) {
                              setSuccess(lang === 'vi' ? "Đã từ chối yêu cầu!" : "Request rejected!");
                              loadVehicleBookings();
                              setSelectedVehicle(null);
                            }
                          }}
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-red-200 transition-all"
                        >
                          {lang === 'vi' ? 'Từ chối' : 'Reject'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <button onClick={() => setSelectedVehicle(null)} className="w-full mt-8 bg-gray-100 hover:bg-gray-200 text-gray-700 py-4 rounded-2xl font-bold transition-all">{lang === 'vi' ? 'Đóng' : 'Close'}</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #E2E8F0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #CBD5E0;
        }
      `}</style>
    </div>
  );
}
