export interface User {
  id: string;
  name: string;
  role?: 'EMPLOYEE' | 'HR_MANAGER';
}

export interface Room {
  id: number;
  name: string;
  capacity: number;
  location: string;
  floor: string;
}

export type RSVPStatus = 'PENDING' | 'ACCEPTED' | 'DECLINED';
export type BookingStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED';

export interface Participant {
  user_id: string;
  user_name: string;
  status: RSVPStatus;
}

export interface Booking {
  id: number;
  booking_code?: string;
  room_id: number;
  room_name?: string;
  title: string;
  organizer_id: string;
  organizer_name: string;
  participants_count: number;
  start_time: string;
  end_time: string;
  invited_participants: Participant[];
  external_participants?: string[];
  user_status?: RSVPStatus;
}

export interface TripParticipant {
  id?: number;
  name: string;
  position: string;
  department: string;
  phone: string;
}

export interface HotelRoom {
  id?: number;
  room_number: number;
  room_type: 'Single' | 'Twin';
  guest_ids: string[]; // References TripParticipant names or indices
}

export interface BusinessTrip {
  id: number;
  booking_code?: string;
  user_id: string;
  user_name: string;
  destination: string;
  purpose: string;
  start_date: string;
  end_date: string;
  city?: string;
  hotel_check_in?: string;
  hotel_check_out?: string;
  hotel_name?: string;
  hotel_location?: string;
  notes?: string;
  status: BookingStatus;
  participants: TripParticipant[];
  rooms: HotelRoom[];
  followers?: string[]; // Array of user IDs
  hr_comment?: string;
  processed_at?: string;
  created_at?: string;
}

export interface Notification {
  id: number;
  user_id: string;
  message: string;
  type: string;
  related_id?: number;
  is_read: number;
  created_at: string;
}

export interface HotelBooking {
  id: number;
  trip_id: number;
  hotel_name: string;
  location: string;
  check_in: string;
  check_out: string;
  room_type: string;
}

export interface VehicleBooking {
  id: number;
  booking_code?: string;
  user_id: string;
  user_name?: string;
  trip_id?: number | null;
  type: 'DAILY' | 'TRIP';
  pickup_location: string;
  destination: string;
  pickup_time: string;
  passengers: number;
  status: BookingStatus;
  invited_participants?: Participant[];
  external_participants?: string[];
  hr_comment?: string;
  processed_at?: string;
  created_at?: string;
}
